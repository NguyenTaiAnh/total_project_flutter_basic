import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:start/components/drawer.dart';
import 'package:start/const.dart';
import 'package:start/page/auth/auth_page.dart';
import 'package:start/page/home/widget/home_category.dart';
import 'package:start/page/home/widget/home_slider.dart';
import 'package:start/providers/auth_provider.dart';

class HomePage extends StatelessWidget {
  static const routerName = '/';
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return !auth.isAuth ? AuthPage() : const Home();
      },
    );
  }
}

class Home extends StatelessWidget {
  const Home({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawerCustom,
      appBar: AppBar(
        title: const Text('Home Page'),
      ),
      body: Column(
        children: [
          const HomeSlider(),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text(
                  'Danh mục sản phẩm',
                  style: fdCategory,
                ),
                Text('Tất cả (4)'),
              ],
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          const HomeCategory(),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

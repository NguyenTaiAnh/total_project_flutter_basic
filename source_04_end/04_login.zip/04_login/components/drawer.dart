import 'package:flutter/material.dart';

final drawerCustom = Drawer(
  child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 50),
    width: double.infinity,
    height: double.infinity,
    child: Column(
      children: [
        const SizedBox(
          child: Image(image: AssetImage('assets/images/logo.png')),
        ),
        const SizedBox(
          height: 20,
        ),
        SizedBox(
          height: 500,
          child: SingleChildScrollView(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.home),
                  title: const Text('Home Page'),
                  onTap: () {},
                ),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Logout'),
                  onTap: () {},
                ),
              ],
            ),
          ),
        )
      ],
    ),
  ),
);
